import requests


API_URL = "https://6afddd9b3a0e70bc8d52ea2b.mockapi.io/bookstore/books"


# ---------- a. GET all books ----------
def get_books():
    try:
        response = requests.get(API_URL)
        response.raise_for_status()
        print("GET all books")
        print(response.json())
        print("Status code:", response.status_code)
        return response.json()
    except requests.exceptions.HTTPError as error:
        print("GET failed:", error)


# ---------- b. POST a new book ----------
def add_book(book):
    try:
        response = requests.post(API_URL, json=book)
        response.raise_for_status()
        print("POST new book")
        print(response.json())
        print("Status code:", response.status_code)  # expect 201
        return response.json()
    except requests.exceptions.HTTPError as error:
        print("POST failed:", error)



def update_book(book_id, book):
    try:
        response = requests.put(f"{API_URL}/{book_id}", json=book)
        response.raise_for_status()
        print(f"PUT book {book_id}")
        print(response.json())
        print("Status code:", response.status_code)
        return response.json()
    except requests.exceptions.HTTPError as error:
        print("PUT failed:", error)



def delete_book(book_id):
    try:
        response = requests.delete(f"{API_URL}/{book_id}")
        response.raise_for_status()
        print(f"DELETE book {book_id}")
        print("Status code:", response.status_code)
    except requests.exceptions.HTTPError as error:
        print("DELETE failed:", error)
        return

    
    try:
        check = requests.get(f"{API_URL}/{book_id}")
        check.raise_for_status()
        print("Unexpected: the book still exists:", check.json())
    except requests.exceptions.HTTPError as error:
        print(f"Confirmed: book {book_id} no longer exists ->", error)
        print("Status code:", check.status_code)  # expect 404


def main():
    # a. GET all books
    get_books()
    print("-" * 40)

    # b. POST a 6th book
    new_book = {
        "title": "Clean Code",
        "author": "Robert C. Martin",
        "rating": "9",
    }
    add_book(new_book)
    print("-" * 40)

    # c. PUT: replace book with id 2
    updated_book = {
        "title": "The Pragmatic Programmer",
        "author": "Andrew Hunt",
        "rating": "9",
    }
    update_book(2, updated_book)
    print("-" * 40)

    # d. DELETE book with id 3, then GET it to confirm it is gone
    delete_book(3)
    print("-" * 40)

    # Final list of books
    get_books()


if __name__ == "__main__":
    main()