import flet as ft
import requests


API_URL = "https://6aff00883a0e70bc8d5469cd.mockapi.io/api/tutoring/sessions"
# =======================================

SUBJECTS = ["Mathematics", "Physical Sciences", "English", "Accounting",
            "Life Sciences", "Programming", "Other"]


def main(page: ft.Page):
    page.title = "Tutoring Session Manager"
    page.padding = 20
    page.scroll = ft.ScrollMode.AUTO
    page.theme_mode = ft.ThemeMode.LIGHT

    # ---------- Helpers ----------
    def show_message(text):
        page.open(ft.SnackBar(ft.Text(text)))

    # ---------- Form fields ----------
    student = ft.TextField(label="Student name", expand=True)
    tutor = ft.TextField(label="Tutor name", expand=True)
    subject = ft.Dropdown(
        label="Subject",
        options=[ft.dropdown.Option(s) for s in SUBJECTS],
        expand=True,
    )
    date = ft.TextField(label="Date (e.g. 2026-08-20)", expand=True)
    time = ft.TextField(label="Time (e.g. 14:00)", expand=True)

    sessions_list = ft.Column(spacing=10)
    summary = ft.Text("", weight=ft.FontWeight.BOLD)

    # ---------- API functions ----------
    def get_sessions():
        response = requests.get(API_URL, timeout=10)
        response.raise_for_status()
        return response.json()

    def create_session(data):
        response = requests.post(API_URL, json=data, timeout=10)
        response.raise_for_status()

    def update_session(session_id, data):
        response = requests.put(f"{API_URL}/{session_id}", json=data, timeout=10)
        response.raise_for_status()

    def remove_session(session_id):
        response = requests.delete(f"{API_URL}/{session_id}", timeout=10)
        response.raise_for_status()

    # ---------- Actions ----------
    def toggle_status(session):
        new_status = "Completed" if session.get("status") != "Completed" else "Scheduled"
        try:
            update_session(session["id"], {"status": new_status})
            show_message(f"Marked as {new_status}")
            refresh()
        except Exception as e:
            show_message(f"Could not update: {e}")

    def delete_clicked(session):
        try:
            remove_session(session["id"])
            show_message("Session deleted")
            refresh()
        except Exception as e:
            show_message(f"Could not delete: {e}")

    def add_clicked(e):
        if not all([student.value, tutor.value, subject.value, date.value, time.value]):
            show_message("Please fill in all the fields")
            return
        data = {
            "student": student.value.strip(),
            "tutor": tutor.value.strip(),
            "subject": subject.value,
            "date": date.value.strip(),
            "time": time.value.strip(),
            "status": "Scheduled",
        }
        try:
            create_session(data)
            show_message("Session booked!")
            student.value = ""
            tutor.value = ""
            subject.value = None
            date.value = ""
            time.value = ""
            refresh()
        except Exception as ex:
            show_message(f"Could not save: {ex}")

    # ---------- Build the list ----------
    def make_card(s):
        done = s.get("status") == "Completed"
        return ft.Card(
            content=ft.Container(
                padding=15,
                content=ft.Row(
                    [
                        ft.Column(
                            [
                                ft.Text(
                                    s.get("subject", ""),
                                    size=18,
                                    weight=ft.FontWeight.BOLD,
                                ),
                                ft.Text(f"Student: {s.get('student', '')}"),
                                ft.Text(f"Tutor: {s.get('tutor', '')}"),
                                ft.Text(f"When: {s.get('date', '')} at {s.get('time', '')}"),
                                ft.Text(
                                    f"Status: {s.get('status', 'Scheduled')}",
                                    color=ft.Colors.GREEN if done else ft.Colors.ORANGE,
                                    weight=ft.FontWeight.W_500,
                                ),
                            ],
                            expand=True,
                            spacing=3,
                        ),
                        ft.IconButton(
                            icon=ft.Icons.CHECK_CIRCLE if done else ft.Icons.CHECK_CIRCLE_OUTLINE,
                            icon_color=ft.Colors.GREEN,
                            tooltip="Toggle completed",
                            on_click=lambda e, s=s: toggle_status(s),
                        ),
                        ft.IconButton(
                            icon=ft.Icons.DELETE,
                            icon_color=ft.Colors.RED,
                            tooltip="Delete",
                            on_click=lambda e, s=s: delete_clicked(s),
                        ),
                    ]
                ),
            )
        )

    def refresh():
        sessions_list.controls.clear()
        try:
            data = get_sessions()
            if not data:
                sessions_list.controls.append(ft.Text("No sessions booked yet."))
            for s in data:
                sessions_list.controls.append(make_card(s))
            completed = sum(1 for s in data if s.get("status") == "Completed")
            summary.value = f"Total: {len(data)}  |  Completed: {completed}  |  Upcoming: {len(data) - completed}"
        except Exception as e:
            sessions_list.controls.append(ft.Text(f"Could not load sessions: {e}", color=ft.Colors.RED))
        page.update()

    # ---------- Layout ----------
    page.add(
        ft.Text("Tutoring Session Manager", size=28, weight=ft.FontWeight.BOLD),
        ft.Text("Book and manage tutoring sessions", color=ft.Colors.GREY_700),
        ft.Divider(),
        ft.Text("Book a new session", size=20, weight=ft.FontWeight.W_600),
        ft.Row([student, tutor]),
        ft.Row([subject, date, time]),
        ft.ElevatedButton("Book session", icon=ft.Icons.ADD, on_click=add_clicked),
        ft.Divider(),
        ft.Row(
            [
                ft.Text("All sessions", size=20, weight=ft.FontWeight.W_600),
                ft.IconButton(icon=ft.Icons.REFRESH, tooltip="Refresh", on_click=lambda e: refresh()),
            ]
        ),
        summary,
        sessions_list,
    )

    refresh()


ft.app(target=main, view=ft.AppView.WEB_BROWSER)